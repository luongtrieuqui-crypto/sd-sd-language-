const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
function make() {
  const w = new BrowserWindow({ width: 1280, height: 800, title: 'Sd IDE', webPreferences: { contextIsolation: true, sandbox: true } });
  Menu.setApplicationMenu(null);
  w.loadFile(path.join(__dirname, 'sd-ide-offline.html'));
}
app.whenReady().then(make);
app.on('window-all-closed', () => app.quit());
