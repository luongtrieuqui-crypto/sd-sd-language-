#!/usr/bin/env node
// sd - chay chuong trinh Sd 2 / Sd++ (.sd, .sdpp), ho tro du an nhieu tep:
//   node sd.js chinh.sd            nhap tu ban phim
//   node sd.js chinh.sd < nhap.txt nhap tu tep
// 'imp*toan.ed' se tim toan.sd hoac toan.sdpp cung thu muc voi tep chinh.
const fs = require('fs');
const path = require('path');
const { createDebug, runSource } = require('./sdcore.js');
const f = process.argv[2];
if (!f) { console.error('Dung: node sd.js <tep.sd | tep.sdpp>'); process.exit(64); }
let src; try { src = fs.readFileSync(f, 'utf8'); } catch (e) { console.error('Khong doc duoc ' + f); process.exit(66); }
const dir = path.dirname(path.resolve(f));
const key = (n) => n.replace(/\.(sdpp|sd|txt)$/i, '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/[^\w]/g, '_');
function load(name) {
  const k = key(name);
  for (const n of fs.readdirSync(dir)) if (/\.(sd|sdpp)$/i.test(n) && key(n) === k) return fs.readFileSync(path.join(dir, n), 'utf8').replace(/\r\n?/g, '\n');
  return null;
}
const opts = { load, entry: key(path.basename(f)) };
function warn(w) { for (const x of (w || [])) console.error(`[CANH BAO ${x.code}${x.file ? ' tep ' + x.file : ''} @dong ${x.line}] ${x.msg}`); }
function fail(x) { console.error(`[LOI ${x.code}${x.file ? ' tep ' + x.file : ''}${x.line ? ' @dong ' + x.line : ''}] ${x.msg}`); process.exit(255); }
src = src.replace(/\r\n?/g, '\n');
if (!process.stdin.isTTY) {                       // du lieu nhap qua ong dan
  let inp = ''; try { inp = fs.readFileSync(0, 'utf8'); } catch (e) {}
  const r = runSource(src, inp, opts); process.stdout.write(r.out);
  warn(r.warnings);
  if (r.fault) fail(r.fault); process.exit(r.rc & 255);
}
function readLine() {                             // doc mot dong tu ban phim
  const b = Buffer.alloc(1); let s = '';
  for (;;) {
    let n; try { n = fs.readSync(0, b, 0, 1, null); } catch (e) { if (e.code === 'EAGAIN') continue; if (e.code === 'EOF') n = 0; else throw e; }
    if (n === 0) return null; const c = b.toString(); if (c === '\n') return s.replace(/\r$/, ''); s += c;
  }
}
const d = createDebug(src, '', (t) => process.stdout.write(t), opts);
if (d.fault) fail(d.fault);
while (!d.done) {
  if (d.waiting) { const l = readLine(); if (l === null) fail({ code: 'E403', msg: 'het du lieu nhap', line: d.pos.line }); d.next(l); }
  else d.next();
}
warn(d.warnings);
if (d.fault) fail(d.fault);
process.exit(d.rc & 255);
