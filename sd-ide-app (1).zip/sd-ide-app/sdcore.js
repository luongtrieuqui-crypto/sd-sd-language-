/* Thong dich Sd 2 (Phan I) - cong tu sdi.py */
class SdFault extends Error {
  constructor(code, msg, line) { super(msg); this.code = code; this.msg = msg; this.line = line; this.file = null; }
}
class Brk {} class Nxt {}
class Ret { constructor(v) { this.v = v; } }
class NeedInput {}
function splitIn(t){ if(!t) return []; const a=t.split('\n'); if(a.length&&a[a.length-1]==='') a.pop(); return a; }
class SbBack {} class SbExit {}
class NullPtr {} const NULLP = new NullPtr();
class VarPtr { constructor(scope, name) { this.scope = scope; this.name = name; } }
class ElemPtr { constructor(arr, idx, blk) { this.arr = arr; this.idx = idx; this.blk = blk; } }
class FldPtr { constructor(obj, name) { this.obj = obj; this.name = name; } }
const isPtr = (x) => x instanceof VarPtr || x instanceof ElemPtr || x instanceof FldPtr || x instanceof NullPtr;
const PARSE_WARN = [];
const STDLIBS = new Set(['ioprt', 'math', 'mem', 'str', 'sys', 'file', 'draw']);
class Fl { constructor(v) { this.v = v; } }
class Struct { constructor(f) { this.f = f; } }
const nv = (x) => (x instanceof Fl ? x.v : typeof x === 'boolean' ? (x ? 1 : 0) : x);
const isNum = (x) => typeof x === 'number' || x instanceof Fl || typeof x === 'boolean';
const truthy = (v) => (v instanceof Fl ? v.v !== 0 : v instanceof NullPtr ? false : Array.isArray(v) ? v.length > 0 : !!v);
const TYPES = new Set(['int', 'float', 'str', 'bool', 'ptr']);
const MAXSAFE = 9007199254740991;
const STEP_LIMIT = 4000000, OUT_LIMIT = 400000, DEPTH_LIMIT = 800;

function stripComments(src) {
  const out = []; let inb = false, openl = 0;
  src.split('\n').forEach((line, idx) => {
    const n = idx + 1; let res = '', pos = 0;
    while (pos < line.length) {
      const j = line.indexOf('\\\\', pos);
      if (inb) { if (j < 0) pos = line.length; else { pos = j + 2; inb = false; } }
      else if (j < 0) { res += line.slice(pos); pos = line.length; }
      else { res += line.slice(pos, j); pos = j + 2; inb = true; openl = n; }
    }
    out.push([n, res.trim()]);
  });
  if (inb) throw new SdFault('E101', `ghi chú mở ở dòng ${openl} không được đóng`, openl);
  return out.filter(([, s]) => s);
}

const TOK = /\s*(\d+\.\d+|\d+|"[^"]*"|[A-Za-z_]\w*|==|!=|<=|>=|\+\+|--|[-+*/%()<>=\[\].'@,])/y;
function tokenize(s, line) {
  const toks = []; s = s.trim(); let pos = 0;
  while (pos < s.length) {
    TOK.lastIndex = pos; const m = TOK.exec(s);
    if (!m) throw new SdFault('E102', `ký tự lạ: ${s.slice(pos, pos + 8)}`, line);
    toks.push(m[1]); pos = TOK.lastIndex;
    while (pos < s.length && /\s/.test(s[pos])) pos++;
  }
  return toks;
}

const BIN = [['or'], ['and'], ['==', '!='], ['<', '<=', '>', '>='], ['+', '-'], ['*', '/', '%']];
class P {
  constructor(t, line) { this.t = t; this.i = 0; this.line = line; }
  peek() { return this.i < this.t.length ? this.t[this.i] : null; }
  nxt() { const v = this.peek(); this.i++; return v; }
  eat(v) {
    if (this.peek() !== v) throw new SdFault('E201', `mong đợi '${v}', gặp '${this.peek() === null ? 'hết dòng' : this.peek()}'`, this.line);
    this.i++;
  }
  expr(lvl = 0) {
    if (lvl === BIN.length) return this.unary();
    let l = this.expr(lvl + 1);
    while (this.peek() !== null && BIN[lvl].includes(this.peek())) { const op = this.nxt(); l = ['bin', op, l, this.expr(lvl + 1)]; }
    return l;
  }
  unary() {
    if (this.peek() === 'not') { this.nxt(); return ['not', this.unary()]; }
    if (this.peek() === '-') { this.nxt(); return ['neg', this.unary()]; }
    if (this.peek() === '*') { this.nxt(); return ['deref', this.unary()]; }
    if (this.peek() === '@') { this.nxt(); return ['addr', this.unary()]; }
    return this.postfix();
  }
  sep() {
    if (this.peek() === "'") this.nxt();
    else if (this.peek() === ',') { this.nxt(); PARSE_WARN.push({ code: 'W202', line: this.line, msg: "dấu ',' ngăn phần tử là dạng cũ, hãy dùng dấu '" }); }
  }
  args() {
    const a = []; this.eat('(');
    while (this.peek() !== ')') {
      if (this.peek() === null) throw new SdFault('E201', "thiếu ')'", this.line);
      a.push(this.expr()); this.sep();
    }
    this.eat(')'); return a;
  }
  postfix() {
    const t = this.nxt(); let e;
    if (t === null) throw new SdFault('E201', 'biểu thức bị thiếu', this.line);
    if (t === '(') { e = this.expr(); this.eat(')'); }
    else if (t === '[') {
      const items = [];
      while (this.peek() !== ']') {
        if (this.peek() === null) throw new SdFault('E201', "thiếu ']'", this.line);
        items.push(this.expr()); this.sep();
      }
      this.eat(']'); e = ['list', items];
    }
    else if (/^\d+$/.test(t)) e = ['num', parseInt(t, 10)];
    else if (/^\d+\.\d+$/.test(t)) e = ['num', new Fl(parseFloat(t))];
    else if (t[0] === '"') e = ['str', t.slice(1, -1)];
    else if (t === 'true' || t === 'false') e = ['num', t === 'true'];
    else if (!/^[A-Za-z_]/.test(t)) throw new SdFault('E201', `không mong đợi '${t}'`, this.line);
    else if (t === 'ids' && this.peek() === '(') {
      this.nxt(); const nm = this.nxt(); this.eat(')'); this.eat('.'); this.eat('g'); e = ['gvar', nm];
    }
    else {
      e = ['var', t];
      if (['str', 'math', 'file', 'sys', 'mem', 'sta', 'draw'].includes(t) && this.peek() === '.') {
        this.nxt(); const f = this.nxt(); e = ['call', `${t}.${f}`, this.args()];
      } else if (this.peek() === '(') e = ['call', t, this.args()];
    }
    for (;;) {
      if (this.peek() === '[') { this.nxt(); const i = this.expr(); this.eat(']'); e = ['idx', e, i]; }
      else if (this.peek() === '.') { this.nxt(); e = ['fld', e, this.nxt()]; }
      else break;
    }
    return e;
  }
}
function parseExpr(s, line) {
  const p = new P(tokenize(s, line), line); const e = p.expr();
  if (p.peek() !== null) throw new SdFault('E201', `thừa '${p.peek()}'`, line);
  return e;
}
function inner(s, start, line) {
  if (s[start] !== '(') throw new SdFault('E201', "mong đợi '('", line);
  let d = 0;
  for (let k = start; k < s.length; k++) {
    if (s[k] === '(') d++;
    else if (s[k] === ')') { d--; if (d === 0) return [s.slice(start + 1, k), k + 1]; }
  }
  throw new SdFault('E201', "thiếu ')'", line);
}
function splitTop(s, sep = "'") {
  const parts = []; let d = 0, cur = '', q = false;
  for (const ch of s) {
    if (ch === '"') q = !q;
    if (!q) { if ('([{'.includes(ch)) d++; else if (')]}'.includes(ch)) d--; }
    if (ch === sep && d === 0 && !q) { parts.push(cur); cur = ''; } else cur += ch;
  }
  parts.push(cur);
  return parts.map((p) => p.trim()).filter((p) => p);
}
function findAssign(s) {
  for (let k = 0; k < s.length; k++) {
    if (s[k] !== '=') continue;
    if (k > 0 && '=!<>'.includes(s[k - 1])) continue;
    if (s[k + 1] === '=') continue;
    return k;
  }
  return -1;
}

class Prog {
  constructor(src, ctx) {
    this.ctx = ctx || { stack: [], done: new Set(), load: null };
    this.lines = stripComments(src);
    this.fns = new Map(); this.structs = new Map(); this.main = null; this.i = 0;
    this.globalInit = []; this.alias = Object.create(null); this.warnings = []; this.isPP = false;
    try { this.top(); }
    catch (e) {
      if (e instanceof SdFault) throw e;
      const k = Math.min(this.i, this.lines.length - 1);
      throw new SdFault('E202', 'cú pháp không hợp lệ', k >= 0 ? this.lines[k][0] : 0);
    }
  }
  cur() {
    if (this.i >= this.lines.length) {
      const last = this.lines.length ? this.lines[this.lines.length - 1][0] : 0;
      throw new SdFault('E201', 'hết tệp nhưng còn khối chưa đóng', last);
    }
    return this.lines[this.i];
  }
  top() {
    const L = this.lines;
    while (this.i < L.length) {
      const [n, s] = L[this.i];
      if (s.startsWith('imp*')) this.doImport(n, s);
      else if (s === 'sta(main){') { this.i++; this.main = this.body()[0]; }
      else if (s === 'iid: sta(struct) => dta:') {
        const s2 = this.lines[this.i + 1][1];
        const m = /^sta (\w+) \{ (.*) \}$/.exec(s2);
        const fields = splitTop(m[2]).map((f) => { const [t, nm] = f.split(/\s+/); return [t, nm]; });
        this.structs.set(m[1], fields); this.i += 2; this.closer('strt ed');
      }
      else if (s === 'iid: sta(fn) => rtn:' || s === 'iid: sta(void) => unkw:') {
        const kind = s.includes('fn') ? 'fn' : 'void';
        const n2 = this.lines[this.i + 1][0], s2 = this.lines[this.i + 1][1];
        const m = /^sta (\w+)\((.*?)\)( -> \w+)? \{$/.exec(s2);
        const params = splitTop(m[2]).map((p) => { const mm = /^(\w+) (\w+)(\[\d+\])?$/.exec(p); return [mm[1], mm[2]]; });
        this.i += 2;
        const body = this.body()[0];
        this.closer(kind + ' ed');
        this.fns.set(m[1], { params, body, line: n2 });
      }
      else if (!this.topItem(n, s)) throw new SdFault('E202', `không nhận dạng được: ${s}`, n);
    }
  }
  doImport(n, s) {
    const m = /^imp\*(\w+)\.(?:ed|\$)$/.exec(s);
    if (!m) throw new SdFault('E202', "imp* cần dạng 'imp*tên.ed' (hoặc 'imp*tên.$' trong Sd++)", n);
    const name = m[1]; this.i++;
    if (STDLIBS.has(name)) return;
    const ctx = this.ctx;
    const key = name.toLowerCase();
    if (ctx.stack.includes(key)) throw new SdFault('E211', `nhập vòng tròn: ${ctx.stack.concat([key]).join(' -> ')}`, n);
    if (ctx.done.has(key)) return;
    const src = ctx.load ? ctx.load(name) : null;
    if (src === null || src === undefined) throw new SdFault('E205', `không tìm thấy thư viện hoặc tệp '${name}' (thư viện chuẩn: ${[...STDLIBS].join(', ')})`, n);
    ctx.done.add(key);
    let sub;
    try { sub = buildProg(src, { load: ctx.load, stack: ctx.stack.concat([key]), done: ctx.done }); }
    catch (e) { if (e instanceof SdFault && !e.file) e.file = key; throw e; }
    for (const [k, v] of sub.fns) {
      if (this.fns.has(k)) throw new SdFault('E302', `trùng tên hàm '${k}' (từ tệp '${name}')`, n);
      if (!v.file) v.file = key; this.fns.set(k, v);
    }
    for (const [k, v] of sub.structs) {
      if (this.structs.has(k)) throw new SdFault('E302', `trùng tên cấu trúc '${k}' (từ tệp '${name}')`, n);
      this.structs.set(k, v);
    }
    this.globalInit.push(...sub.globalInit);
    for (const w of sub.warnings) this.warnings.push(Object.assign({ file: key }, w));
  }
  topItem() { return false; }
  isClose(s) { return s === '}'; }
  closer(want) {
    const [n, s] = this.cur();
    if (s !== want) throw new SdFault('E202', `mong đợi '${want}', gặp '${s}'`, n);
    this.i++;
  }
  body() {
    const stmts = [];
    for (;;) {
      const [n, s] = this.cur();
      if (this.isClose(s)) { this.i++; return [stmts, n]; }
      stmts.push(this.stmt());
    }
  }
  stmt() {
    const [n, s] = this.cur();
    if (s === 'iid: sta(bolean) => cdn,tf:') {
      this.i++; const br = [];
      while (this.cur()[1] !== 'bln ed') {
        const [nb, sb] = this.cur();
        const m = /^sta\((.*)\) \{$/.exec(sb);
        if (!m) throw new SdFault('E202', `mong đợi nhánh 'sta(điều kiện) {' hoặc 'bln ed', gặp '${sb}'`, nb);
        this.i++;
        const cond = m[1] === 'else' ? null : parseExpr(m[1], nb);
        br.push([cond, this.body()[0]]);
      }
      this.i++;
      return ['if', n, br];
    }
    if (s === 'iid: sta(for) => cdn,chck:' || s === 'iid: sta(while) => cdn,edt:') {
      const kind = s.includes('for') ? 'for' : 'while';
      this.i++;
      const [n2, s2] = this.cur();
      const m = /^dbl sta\((.*)\) \{$/.exec(s2);
      if (!m) throw new SdFault('E202', `mong đợi 'dbl sta(...) {', gặp '${s2}'`, n2);
      this.i++;
      const body = this.body()[0]; this.closer('dbl ed');
      if (kind === 'while') return ['while', n, parseExpr(m[1], n2), body];
      const parts = splitTop(m[1]);
      if (parts.length !== 3) throw new SdFault('E201', "vòng for cần 3 phần cách nhau bởi dấu '", n2);
      return ['for', n, this.simple('sta(' + parts[0] + ')', n2), parseExpr(parts[1], n2), this.simple('sta(' + parts[2] + ')', n2), body];
    }
    if (!s.startsWith('iid:')) throw new SdFault('E202', `không nhận dạng được: ${s}`, n);
    this.i++;
    if (!s.endsWith(' ed')) throw new SdFault('E201', "thiếu chốt 'ed' ở cuối lệnh", n);
    return this.simple(s.slice(5, -3).trim(), n);
  }
  simple(t, n) {
    if (t.startsWith('ref*')) return ['ret', n, parseExpr(t.slice(4), n)];
    if (t === 'brk') return ['brk', n];
    if (t === 'nxt') return ['nxt', n];
    if (t.startsWith('call ')) return ['expr', n, parseExpr(t.slice(5), n)];
    if (!t.startsWith('sta(')) throw new SdFault('E202', `lệnh lạ: ${t}`, n);
    const [head, nx] = inner(t, 3, n);
    const rest = t.slice(nx).trim();
    if (head === 'pri') return ['pri', n, rest.slice(2).trim()];
    if (head === 'ipt') {
      const at = rest.indexOf('sta(');
      if (at < 0) throw new SdFault('E201', "ipt cần '=> edt: sta(biến)'", n);
      return ['ipt', n, parseExpr(inner(rest, at + 3, n)[0], n)];
    }
    let mi = /^(\w+) (\w+)\s*=\s*(.+)$/.exec(head);
    if (mi && (TYPES.has(mi[1]) || this.structs.has(mi[1]))) return ['decl', n, mi[1], mi[2], null, parseExpr(mi[3], n)];
    const m = /^(\w+) (\w+)(?:\[(\d+)\])?$/.exec(head);
    if (m && (TYPES.has(m[1]) || this.structs.has(m[1]))) {
      let init = null;
      if (rest) {
        const at = rest.indexOf('sta(');
        if (at < 0) throw new SdFault('E201', "khai báo cần '=> edt: sta(tên = giá trị)'", n);
        const body = inner(rest, at + 3, n)[0]; const k = findAssign(body);
        if (k < 0) throw new SdFault('E201', "thiếu dấu '=' trong phép gán", n);
        init = parseExpr(body.slice(k + 1), n);
      }
      return ['decl', n, m[1], m[2], m[3] ? parseInt(m[3], 10) : null, init];
    }
    if (head.endsWith('++') || head.endsWith('--')) {
      const lhs = parseExpr(head.slice(0, -2), n);
      return ['assign', n, lhs, ['bin', head.slice(-1), lhs, ['num', 1]]];
    }
    const k = findAssign(head);
    if (k < 0) throw new SdFault('E202', `lệnh lạ: ${t}`, n);
    return ['assign', n, parseExpr(head.slice(0, k), n), parseExpr(head.slice(k + 1), n)];
  }
}


function preprocessPP(src) {
  let inB = false;
  const L = src.split('\n').map((line) => {
    let out = '', inS = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (!inS && c === '\\' && line[i + 1] === '\\') { inB = !inB; out += '\\\\'; i++; continue; }
      if (inB) { out += c; continue; }
      if (c === '"') inS = !inS;
      if (!inS && c === '*' && line[i + 1] === '/') break;
      out += c;
    }
    return out;
  });
  const flags = [], R = [];
  const RES = ['$', '₫', '€', '$$', '#', '##'];
  for (let i = 0; i < L.length; i++) {
    const t = L[i].trim();
    const m = /^defk\s*<\s*ids\.end:\s*text\s*"([^"]+)"\s*>\s*\{/.exec(t);
    if (!m) { R.push(L[i]); continue; }
    const ch = m[1];
    if (RES.includes(ch) || flags.includes(ch)) throw new SdFault('E209', `không được định nghĩa lại cờ '${ch}' (dành riêng hoặc đã niêm phong)`, i + 1);
    let j = i + 1, sealed = false, closed = false;
    for (; j < L.length; j++) {
      const u = L[j].replace(/\\\\.*?\\\\/g, '').trim();
      if (/#$/.test(u) && !/##$/.test(u)) sealed = true;
      if (/^\}/.test(u)) { closed = true; break; }
    }
    if (!closed || !sealed) throw new SdFault('E210', "khối defk phải kết thúc bằng '#' trước dấu '}'", i + 1);
    flags.push(ch);
    for (let k = i; k <= j; k++) R.push('');
    i = j;
  }
  if (!flags.length) return R.join('\n');
  return R.map((line) => {
    let out = '', inS = false;
    for (const c of line) {
      if (c === '"') inS = !inS;
      out += (!inS && flags.includes(c)) ? '$' : c;
    }
    return out;
  }).join('\n');
}

class PProg extends Prog {
  isClose(s) { return /^\}\s*[$€]?$/.test(s); }
  warn(code, msg, line) { this.warnings.push({ code, msg, line }); }
  top() {
    this.alias = Object.create(null); this.isPP = true;
    const L = this.lines;
    if (!L.length || L[L.length - 1][1] !== '##') throw new SdFault('E208', "tệp Sd++ phải kết thúc bằng '##'", L.length ? L[L.length - 1][0] : 1);
    L.pop();
    this.autoTerminate();
    super.top();
    if (this.topStmts && this.topStmts.length) {
      if (this.main !== null) throw new SdFault('E214', "lệnh nằm ngoài khung main khi đã có main (đặt lệnh vào main hoặc bỏ main)", this.lines.length ? this.lines[this.lines.length - 1][0] : 1);
      this.main = this.topStmts;
    }
  }
  /* ':&' = ranh gioi tu chot: moi lenh phia tren (den ranh gioi truoc do) duoc compiler tu them co chot. */
  autoTerminate() {
    const L = this.lines;
    let tok = ':&';
    for (const [, s] of L) {
      const m = /^init\.(?:endcomand|endcommand):\s*"([^"]+)"\s*\$$/.exec(s);
      if (m) tok = m[1];
    }
    if (['$', '₫', '€', '$$', '#', '##'].includes(tok)) throw new SdFault('E209', `không được dùng '${tok}' làm ranh giới tự chốt (cờ dành riêng)`, 1);
    for (const x of L) x[1] = x[1].replace(/\s:\s*([$₫€])$/, ' $1');
    const bidx = []; L.forEach(([, s], i) => { if (s === tok) bidx.push(i); });
    if (!bidx.length) return;
    const last = bidx[bidx.length - 1];
    const out = [], stack = []; let hdr = false;
    const hasTerm = (t) => /[$₫€]$/.test(t) || /\$:$/.test(t);
    for (let i = 0; i < L.length; i++) {
      const [n, s0] = L[i]; let s = s0;
      if (s === tok) {
        if (stack.some((k) => k !== 'ssta')) throw new SdFault('E213', `ranh giới '${tok}' phải đặt ngoài mọi khối (chỉ trong ssta hoặc sau nó)`, n);
        continue;
      }
      const auto = i < last;
      if (hdr) { if (s.includes(']{')) { hdr = false; stack.push('define'); } out.push([n, s]); continue; }
      if (/^define\s*\[/.test(s)) { if (s.includes(']{')) stack.push('define'); else hdr = true; out.push([n, s]); continue; }
      if (/^ssta\s*\{$/.test(s)) { stack.push('ssta'); out.push([n, s]); continue; }
      if (/^\}\s*[$€]?$/.test(s)) {
        const k = stack.pop();
        if (auto && s === '}') s = k === 'define' ? '} €' : (k === 'main' || k === 'sb') ? '} $' : '}';
        out.push([n, s]); continue;
      }
      if (/\{$/.test(s)) {
        stack.push(/^ids sb\(/.test(s) ? 'sb' : /^\w+:\s*\{$/.test(s) ? 'main' : 'sd');
        out.push([n, s]); continue;
      }
      if (auto && !hasTerm(s) && !/^(iid:|imp\*|init\b)/.test(s) && !/ ed$/.test(s) && !/^(block\s.+|remaining):$/.test(s) && s !== '$$' && !/^(for|while|bolean|struct|fn|void)\b/.test(s)) {
        if (/^(ids|sta\.arr|ptr)\.g:/.test(s)) s += ' ₫';
        else if (/^ref\*.*:$/.test(s)) s = s.slice(0, -1).trim() + ' $:';
        else s += ' $';
      }
      out.push([n, s]);
    }
    this.lines = out;
  }
  topItem(n, s) {
    const L = this.lines;
    if (/^ssta\s*\{$/.test(s)) { this.i++; return true; }
    if (/^init\.(?:endcomand|endcommand):/.test(s)) { this.i++; return true; }
    if (/^main:\s*\{$/.test(s) && this.main === null) { this.i++; this.main = this.body()[0]; return true; }
    if (s === '}') { this.i++; return true; }
    const m = /^(ids|sta\.arr|ptr)\.g:\s*(\w+)\s*=\s*(.+?)\s*₫$/.exec(s);
    if (m) { this.globalInit.push([m[2], parseExpr(m[3], n), n]); this.i++; return true; }
    if (/^(ids|sta\.arr|ptr)\.g:/.test(s)) throw new SdFault('E201', "khai báo toàn cục cần dạng 'ids.g: tên = giá-trị ₫'", n);
    if (/^define\s*\[/.test(s)) {
      let acc = s.slice(s.indexOf('[') + 1), k = this.i;
      while (!acc.includes(']{')) { k++; if (k >= L.length) throw new SdFault('E201', "thiếu ']{' đóng danh sách define", n); acc += ' ' + L[k][1]; }
      const at = acc.indexOf(']{');
      let mainName = 'main';
      for (const d of splitTop(acc.slice(0, at), ',')) {
        const md = /^(\w+)\.edt:\s*text\s*=\s*"([^"]*)"$/.exec(d);
        if (!md) throw new SdFault('E202', `định nghĩa không hợp lệ: ${d}`, n);
        if (md[1] === 'ids') mainName = md[2]; else this.alias[md[2]] = md[1];
      }
      this.i = k + 1;
      const [n2, s2] = this.cur();
      if (s2 !== mainName + ': {' && s2 !== mainName + ':{') throw new SdFault('E202', `mong đợi '${mainName}: {', gặp '${s2}'`, n2);
      this.i++; this.main = this.body()[0];
      const [n3, s3] = this.cur();
      if (!/^\}\s*€$/.test(s3)) throw new SdFault('E202', `mong đợi '} €' đóng khung define, gặp '${s3}'`, n3);
      this.i++; return true;
    }
    if (/^(sta\(|ids[ .]|iptedt\.|ref\*|\*|@|\$\$$|transf|break|init\b|sta\.|mem\.|[A-Za-z_]\w*\s*(=|\(|\+\+|--|:))/.test(s) && !/^(sta|fn|void|struct|ssta|define|main)\b[^.(]/.test(s)) {
      this.topStmts = this.topStmts || []; this.topStmts.push(this.stmt()); return true;
    }
    return false;
  }
  modifies(x, v) {
    if (!Array.isArray(x)) return false;
    if (x[0] === 'assign' && typeof x[1] === 'number' && Array.isArray(x[2]) && ((x[2][0] === 'var' && x[2][1] === v) || x[2][0] === 'deref')) return true;
    if (x[0] === 'ipt' && x[2] && x[2][0] === 'var' && x[2][1] === v) return true;
    return x.some((c) => this.modifies(c, v));
  }
  stmt() {
    const [n, s0] = this.cur();
    if (s0.startsWith('iid:')) return super.stmt();
    this.i++;
    if (s0 === '$$') return ['sbback', n];
    if (/^transf\s*\$(\s*\$)?$/.test(s0)) {
      if (/\$\s*\$$/.test(s0)) this.warn('W202', "dạng 'transf $ $' là cũ, hãy viết 'transf $'", n);
      return ['sbexit', n, 'transf'];
    }
    if (/^break\s*\$+$/.test(s0)) {
      if (/\$\$$/.test(s0)) this.warn('W202', "dạng 'break $$' là cũ, hãy viết 'break $'", n);
      return ['sbexit', n, 'break'];
    }
    if (/^init\b/.test(s0)) return ['nop', n];
    const mh = /^ids sb\((\w+)\)\s*\{$/.exec(s0);
    if (mh) return this.sbBlock(n, mh[1]);
    let s = s0;
    if (s.endsWith('$:')) s = s.slice(0, -2).trim();
    else if (s.endsWith('$')) s = s.slice(0, -1).trim();
    else throw new SdFault('E201', "thiếu cờ chốt '$' ở cuối lệnh", n);
    if (s.startsWith('ref*')) return ['ret', n, parseExpr(s.slice(4), n)];
    let m = /^(ids\.pri|(\w+)):\s*(.+)$/.exec(s);
    if (m && (m[1] === 'ids.pri' || this.alias[m[2]] === 'pri')) return ['pri', n, m[3].trim()];
    m = /^iptedt\.(\w+)\s+(\w+)\s*(?:=\s*(.+))?$/.exec(s);
    if (m) {
      if (!TYPES.has(m[1]) && !this.structs.has(m[1])) throw new SdFault('E301', `kiểu '${m[1]}' không tồn tại`, n);
      return ['decl', n, m[1], m[2], null, m[3] ? parseExpr(m[3], n) : null];
    }
    if (s.endsWith('++') || s.endsWith('--')) { const lhs = parseExpr(s.slice(0, -2), n); return ['assign', n, lhs, ['bin', s.slice(-1), lhs, ['num', 1]]]; }
    const k = findAssign(s);
    if (k >= 0) return ['assign', n, parseExpr(s.slice(0, k), n), parseExpr(s.slice(k + 1), n)];
    return ['expr', n, parseExpr(s, n)];
  }
  sbBlock(n, v) {
    const branches = [];
    for (;;) {
      const [n2, s2] = this.cur();
      if (this.isClose(s2)) { this.i++; break; }
      const mb = /^block\s+(.+):$/.exec(s2);
      let cond;
      if (mb) cond = parseExpr(mb[1], n2);
      else if (s2 === 'remaining:') cond = null;
      else throw new SdFault('E202', `mong đợi 'block điều-kiện:' hoặc 'remaining:', gặp '${s2}'`, n2);
      this.i++;
      const body = [];
      for (;;) {
        const s3 = this.cur()[1];
        if (this.isClose(s3) || /^block\s+.+:$/.test(s3) || s3 === 'remaining:') break;
        body.push(this.stmt());
      }
      const last = body[body.length - 1];
      if (last && last[0] === 'sbback' && !this.modifies(body, v)) this.warn('W203', `nhánh Reback không thấy sửa biến '${v}' (nguy cơ lặp vô hạn)`, last[1]);
      branches.push([cond, body]);
    }
    return ['sb', n, v, branches];
  }
}
function isPP(src) { return /^\s*ssta\s*\{/m.test(src); }
function buildProg(src, ctx) { return isPP(src) ? new PProg(preprocessPP(src), ctx) : new Prog(src, ctx); }

function fstr(v) {
  if (v instanceof Fl) return Number.isInteger(v.v) ? v.v.toFixed(1) : String(v.v);
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (v instanceof NullPtr) return 'null';
  if (v instanceof VarPtr) return '@' + v.name;
  if (v instanceof ElemPtr) return v.blk ? `@heap[${v.idx}]` : `@mang[${v.idx}]`;
  if (v instanceof FldPtr) return '@' + v.name;
  if (v === null || v === undefined) return 'null';
  if (Array.isArray(v)) return '[' + v.map(fstr).join(', ') + ']';
  if (v instanceof Struct) return '{' + [...v.f].map(([k, x]) => `${k}: ${fstr(x)}`).join(', ') + '}';
  return String(v);
}

class VM {
  constructor(prog, stdin, write) {
    this.p = prog; this.inp = splitIn(stdin); this.ip = 0; this.waitInput = false; this.write = write;
    this.steps = 0; this.depth = 0; this.vfs = new Map();
    this.globals = new Map(); this.heap = []; this.heapCells = 0; this.sbDepth = 0;
  }
  def(typ, size) {
    if (size !== null && size !== undefined) return Array.from({ length: size }, () => this.def(typ, null));
    if (typ === 'int') return 0;
    if (typ === 'float') return new Fl(0);
    if (typ === 'str') return '';
    if (typ === 'bool') return false;
    if (typ === 'ptr') return NULLP;
    const f = new Map(); for (const [t, nm] of this.p.structs.get(typ)) f.set(nm, this.def(t, null));
    return new Struct(f);
  }
  copy(v) {
    if (v instanceof Struct) { const f = new Map(); for (const [k, x] of v.f) f.set(k, this.copy(x)); return new Struct(f); }
    return v;
  }
  lookup(env, name, line) {
    for (let i = env.length - 1; i >= 0; i--) if (env[i].has(name)) return env[i];
    if (this.globals.has(name)) return this.globals;
    throw new SdFault('E301', `biến '${name}' chưa được khai báo`, line);
  }
  initGlobals() {
    for (const [nm, expr, line] of this.p.globalInit) {
      if (this.globals.has(nm)) throw new SdFault('E302', `trùng tên biến toàn cục '${nm}'`, line);
      this.globals.set(nm, this.copy(this.ev(expr, [new Map()], line)));
    }
  }
  leakWarnings() { return this.heap.filter((b) => !b.freed).map((b) => ({ code: 'W302', line: b.line, msg: `vùng nhớ cấp phát ở dòng ${b.line} chưa được sta.free` })); }
  derefGet(p, line) {
    if (p instanceof NullPtr) throw new SdFault('E405', 'giải tham chiếu con trỏ rỗng', line);
    if (p instanceof VarPtr) return p.scope.get(p.name);
    if (p instanceof FldPtr) return p.obj.f.get(p.name);
    if (p instanceof ElemPtr) {
      if (p.blk && p.blk.freed) throw new SdFault('E405', 'đọc vùng nhớ đã sta.free', line);
      if (p.idx < 0 || p.idx >= p.arr.length) throw new SdFault('E408', `truy cập ô ${p.idx} ngoài vùng 0..${p.arr.length - 1}`, line);
      return p.arr[p.idx];
    }
    throw new SdFault('E305', '* chỉ dùng cho con trỏ', line);
  }
  derefSet(p, v, line) {
    if (p instanceof NullPtr) throw new SdFault('E405', 'ghi qua con trỏ rỗng', line);
    if (p instanceof VarPtr) p.scope.set(p.name, v);
    else if (p instanceof FldPtr) p.obj.f.set(p.name, v);
    else if (p instanceof ElemPtr) {
      if (p.blk && p.blk.freed) throw new SdFault('E405', 'ghi vào vùng nhớ đã sta.free', line);
      if (p.idx < 0 || p.idx >= p.arr.length) throw new SdFault('E408', `truy cập ô ${p.idx} ngoài vùng 0..${p.arr.length - 1}`, line);
      p.arr[p.idx] = v;
    } else throw new SdFault('E305', '* chỉ dùng cho con trỏ', line);
  }
  freeCall(e, env, line) {
    if (e[2].length !== 1) throw new SdFault('E304', 'sta.free cần 1 đối số', line);
    const p = this.ev(e[2][0], env, line);
    if (p instanceof NullPtr) throw new SdFault('E406', 'giải phóng con trỏ rỗng hoặc giải phóng hai lần', line);
    if (!(p instanceof ElemPtr) || !p.blk) throw new SdFault('E406', 'chỉ giải phóng được con trỏ do sta.alloc cấp', line);
    if (p.blk.freed) throw new SdFault('E406', 'giải phóng hai lần cùng một vùng nhớ', line);
    if (p.idx !== 0) throw new SdFault('E406', 'phải giải phóng đúng con trỏ đầu vùng', line);
    p.blk.freed = true;
    const t = e[2][0][0];
    if (t === 'var' || t === 'idx' || t === 'fld' || t === 'deref' || t === 'gvar') this.assign(e[2][0], NULLP, env, line);
    return null;
  }
  sbRun(st, env, n) {
    this.sbDepth++; let backs = 0;
    try {
      for (;;) {
        let chosen = null;
        for (const [c, b] of st[3]) if (c !== null && truthy(this.ev(c, env, n))) { chosen = b; break; }
        if (!chosen) { const r = st[3].find((x) => x[0] === null); if (!r) return; chosen = r[1]; }
        try { this.run(chosen, env); return; }
        catch (x) {
          if (x instanceof SbBack) { if (++backs > 65536) throw new SdFault('E402', 'Reback vượt 65536 lần (vòng lặp vô hạn?)', n); if (++this.steps > STEP_LIMIT) throw new SdFault('E501', 'vượt giới hạn số bước', n); continue; }
          if (x instanceof SbExit) return;
          throw x;
        }
      }
    } finally { this.sbDepth--; }
  }
  chk(v, line) {
    if (typeof v === 'number' && !Number.isSafeInteger(v)) throw new SdFault('E405', 'số nguyên vượt quá 2^53 (tràn số)', line);
    return v;
  }
  ptrEq(a, b) {
    if (a instanceof NullPtr || b instanceof NullPtr) return a instanceof NullPtr && b instanceof NullPtr;
    if (a instanceof ElemPtr && b instanceof ElemPtr) return a.arr === b.arr && a.idx === b.idx;
    if (a instanceof VarPtr && b instanceof VarPtr) return a.scope === b.scope && a.name === b.name;
    if (a instanceof FldPtr && b instanceof FldPtr) return a.obj === b.obj && a.name === b.name;
    return false;
  }
  arith(op, a, b, line) {
    if (isPtr(a) || isPtr(b)) {
      if (op === '==' || op === '!=') { const eq = this.ptrEq(a, b); return op === '==' ? eq : !eq; }
      if ((op === '+' || op === '-') && isPtr(a) && typeof b === 'number') {
        if (a instanceof NullPtr) throw new SdFault('E405', 'số học trên con trỏ rỗng', line);
        if (a instanceof ElemPtr) return new ElemPtr(a.arr, a.idx + (op === '+' ? b : -b), a.blk);
        if (b === 0) return a;
        throw new SdFault('E408', 'số học con trỏ chỉ dùng trong vùng mảng hoặc Heap', line);
      }
      if (op === '+' && typeof a === 'number' && isPtr(b)) return this.arith('+', b, a, line);
      if (op === '-' && a instanceof ElemPtr && b instanceof ElemPtr && a.arr === b.arr) return a.idx - b.idx;
      throw new SdFault('E305', `không thể dùng '${op}' với con trỏ`, line);
    }
    if (op === '+' && typeof a === 'string' && typeof b === 'string') return a + b;
    if (!isNum(a) || !isNum(b)) {
      if (['==', '!='].includes(op) || (typeof a === 'string' && typeof b === 'string' && ['<', '<=', '>', '>='].includes(op))) {
        const eq = a === b;
        if (op === '==') return eq; if (op === '!=') return !eq;
        return { '<': a < b, '<=': a <= b, '>': a > b, '>=': a >= b }[op];
      }
      throw new SdFault('E305', `sai kiểu: không thể dùng '${op}' giữa ${this.tn(a)} và ${this.tn(b)}`, line);
    }
    const fl = a instanceof Fl || b instanceof Fl; const x = nv(a), y = nv(b);
    switch (op) {
      case '+': return fl ? new Fl(x + y) : this.chk(x + y, line);
      case '-': return fl ? new Fl(x - y) : this.chk(x - y, line);
      case '*': return fl ? new Fl(x * y) : this.chk(x * y, line);
      case '/': if (y === 0) throw new SdFault('E401', 'chia cho 0', line); return fl ? new Fl(x / y) : Math.trunc(x / y);
      case '%': if (y === 0) throw new SdFault('E401', 'chia cho 0', line); return fl ? new Fl(x % y) : x % y;
      case '==': return x === y; case '!=': return x !== y;
      case '<': return x < y; case '<=': return x <= y; case '>': return x > y; default: return x >= y;
    }
  }
  tn(v) { return isPtr(v) ? 'ptr' : v instanceof Fl ? 'float' : typeof v === 'number' ? 'int' : typeof v === 'string' ? 'str' : typeof v === 'boolean' ? 'bool' : Array.isArray(v) ? 'mảng' : 'cấu trúc'; }
  ev(e, env, line) {
    const k = e[0];
    if (k === 'num' || k === 'str' || k === 'val') return e[1];
    if (k === 'var') return this.lookup(env, e[1], line).get(e[1]);
    if (k === 'gvar') { if (!this.globals.has(e[1])) throw new SdFault('E301', `biến toàn cục '${e[1]}' chưa khai báo`, line); return this.globals.get(e[1]); }
    if (k === 'deref') return this.derefGet(this.ev(e[1], env, line), line);
    if (k === 'addr') {
      const t = e[1];
      if (t[0] === 'var') { const sc = this.lookup(env, t[1], line), v = sc.get(t[1]); return Array.isArray(v) ? new ElemPtr(v, 0, null) : new VarPtr(sc, t[1]); }
      if (t[0] === 'gvar') { if (!this.globals.has(t[1])) throw new SdFault('E301', `biến toàn cục '${t[1]}' chưa khai báo`, line); const v = this.globals.get(t[1]); return Array.isArray(v) ? new ElemPtr(v, 0, null) : new VarPtr(this.globals, t[1]); }
      if (t[0] === 'idx') { const arr = this.ev(t[1], env, line), iv = this.ev(t[2], env, line); if (!Array.isArray(arr) || typeof iv !== 'number') throw new SdFault('E305', '@a[i] cần mảng và chỉ số nguyên', line); return new ElemPtr(arr, iv, null); }
      if (t[0] === 'fld') { const o = this.ev(t[1], env, line); if (!(o instanceof Struct)) throw new SdFault('E305', '@x.f cần cấu trúc', line); return new FldPtr(o, t[2]); }
      if (t[0] === 'deref') return this.ev(t[1], env, line);
      throw new SdFault('E303', 'không lấy được địa chỉ của biểu thức này', line);
    }
    if (k === 'list') return e[1].map((x) => this.ev(x, env, line));
    if (k === 'neg') { const v = this.ev(e[1], env, line); if (!isNum(v)) throw new SdFault('E305', 'dấu - cần số', line); return v instanceof Fl ? new Fl(-v.v) : -nv(v); }
    if (k === 'not') return !truthy(this.ev(e[1], env, line));
    if (k === 'idx') {
      const b = this.ev(e[1], env, line), iv = this.ev(e[2], env, line);
      if (!Array.isArray(b) && typeof b !== 'string') throw new SdFault('E305', 'chỉ số [] chỉ dùng cho mảng hoặc chuỗi', line);
      if (typeof iv !== 'number') throw new SdFault('E305', 'chỉ số phải là số nguyên', line);
      if (iv < 0 || iv >= b.length) throw new SdFault('E404', `chỉ số ${iv} ngoài khoảng 0..${b.length - 1}`, line);
      return b[iv];
    }
    if (k === 'fld') {
      const o = this.ev(e[1], env, line);
      if (!(o instanceof Struct) || !o.f.has(e[2])) throw new SdFault('E301', `không có trường '${e[2]}'`, line);
      return o.f.get(e[2]);
    }
    if (k === 'call') { if (e[1] === 'sta.free') return this.freeCall(e, env, line); return this.call(e[1], e[2].map((a) => this.ev(a, env, line)), line); }
    const op = e[1], a = this.ev(e[2], env, line);
    if (op === 'and') return truthy(a) ? this.ev(e[3], env, line) : a;
    if (op === 'or') return truthy(a) ? a : this.ev(e[3], env, line);
    return this.arith(op, a, this.ev(e[3], env, line), line);
  }
  call(name, args, line) {
    const fn = this.p.fns.get(name);
    if (fn) {
      if (fn.params.length !== args.length) throw new SdFault('E304', `${name}: cần ${fn.params.length} đối số, nhận ${args.length}`, line);
      if (++this.depth > DEPTH_LIMIT) throw new SdFault('E402', 'tràn ngăn xếp (đệ quy quá sâu)', line);
      const sc = new Map(); fn.params.forEach(([, pn], i) => sc.set(pn, this.copy(args[i])));
      try { this.run(fn.body, [sc]); }
      catch (r) { if (r instanceof Ret) return this.copy(r.v); if (r instanceof SdFault && !r.file && fn.file) r.file = fn.file; throw r; }
      finally { this.depth--; }
      return null;
    }
    const need = (n) => { if (args.length !== n) throw new SdFault('E304', `${name}: cần ${n} đối số`, line); };
    const str = (v) => { if (typeof v !== 'string') throw new SdFault('E305', `${name} cần chuỗi`, line); return v; };
    const num = (v) => { if (!isNum(v)) throw new SdFault('E305', `${name} cần số`, line); return v; };
    switch (name) {
      case 'str.len': need(1); return str(args[0]).length;
      case 'str.upper': need(1); return str(args[0]).toUpperCase();
      case 'str.lower': need(1); return str(args[0]).toLowerCase();
      case 'str.concat': need(2); return str(args[0]) + str(args[1]);
      case 'math.abs': need(1); return num(args[0]) instanceof Fl ? new Fl(Math.abs(args[0].v)) : Math.abs(nv(args[0]));
      case 'math.sqrt': need(1); if (nv(num(args[0])) < 0) throw new SdFault('E401', 'căn của số âm', line); return new Fl(Math.sqrt(nv(args[0])));
      case 'math.max': case 'math.min': {
        if (args.length < 1) throw new SdFault('E304', `${name}: cần ít nhất 1 đối số`, line);
        args.forEach(num);
        return args.reduce((p, c) => ((name === 'math.max' ? nv(c) > nv(p) : nv(c) < nv(p)) ? c : p));
      }
      case 'math.pow': {
        need(2); num(args[0]); num(args[1]);
        const r = Math.pow(nv(args[0]), nv(args[1]));
        if (typeof args[0] === 'number' && typeof args[1] === 'number' && args[1] >= 0) return this.chk(r, line);
        return new Fl(r);
      }
      case 'sta.alloc': {
        need(1); const nb = nv(num(args[0])), cells = Math.ceil(nb / 8);
        if (!(nb > 0)) throw new SdFault('E407', 'kích thước cấp phát phải dương', line);
        if (this.heapCells + cells > 2000000) throw new SdFault('E407', 'hết bộ nhớ Heap', line);
        const blk = { freed: false, line, cells: new Array(cells).fill(0) };
        this.heap.push(blk); this.heapCells += cells; return new ElemPtr(blk.cells, 0, blk);
      }
      case 'mem.memset': {
        need(3); const p = args[0], cnt = nv(num(args[2]));
        if (!(p instanceof ElemPtr)) throw new SdFault('E305', 'mem.memset cần con trỏ vùng nhớ', line);
        for (let q = 0; q < cnt; q++) this.derefSet(new ElemPtr(p.arr, p.idx + q, p.blk), args[1], line);
        return null;
      }
      case 'sys.time': need(0); return new Fl(Date.now() / 1000);
      case 'sys.sleep': need(1); num(args[0]); return null;
      case 'draw.rect': {
        need(4); const [x, , w, h] = args.map((a) => Math.trunc(nv(num(a))));
        if (w < 2 || h < 2 || w > 200 || h > 100) throw new SdFault('E401', 'draw.rect: rộng 2..200, cao 2..100', line);
        const pad = ' '.repeat(Math.max(0, x));
        for (let r = 0; r < h; r++) this.write(pad + (r === 0 || r === h - 1 ? '+' + '-'.repeat(w - 2) + '+' : '|' + ' '.repeat(w - 2) + '|') + '\n', line);
        return null;
      }
      case 'file.write': need(2); this.vfs.set(str(args[0]), str(args[1])); return null;
      case 'file.read': {
        need(1); const p = str(args[0]);
        if (!this.vfs.has(p)) throw new SdFault('E403', `không có tệp '${p}' (tệp chỉ tồn tại trong phiên chạy)`, line);
        return this.vfs.get(p);
      }
      default: throw new SdFault('E301', `hàm '${name}' chưa tồn tại`, line);
    }
  }
  fmt(s, env, line) {
    let res = '', i = 0;
    while (i < s.length) {
      if (s.startsWith('//', i)) { res += '/'; i += 2; continue; }
      const m = /^\/([sdfb])(\d?)\{/.exec(s.slice(i, i + 4));
      if (!m) { res += s[i]; i++; continue; }
      const j = i + m[0].length; let d = 1, k = j;
      while (d) {
        if (k >= s.length) throw new SdFault('E201', "thiếu '}' đóng chỗ giữ chỗ", line);
        if (s[k] === '{') d++; else if (s[k] === '}') d--; k++;
      }
      const v = this.ev(parseExpr(s.slice(j, k - 1), line), env, line);
      const c = m[1];
      if (c === 's') res += fstr(v);
      else if (c === 'b') res += truthy(v) ? 'true' : 'false';
      else {
        if (!isNum(v)) throw new SdFault('E305', `/${c}{} cần số, nhận ${this.tn(v)}`, line);
        res += c === 'd' ? String(Math.trunc(nv(v))) : nv(v).toFixed(m[2] === '' ? 2 : parseInt(m[2], 10));
      }
      i = k;
    }
    return res;
  }
  assign(lhs, val, env, line) {
    const k = lhs[0];
    if (k === 'var') this.lookup(env, lhs[1], line).set(lhs[1], val);
    else if (k === 'idx') {
      const b = this.ev(lhs[1], env, line), iv = this.ev(lhs[2], env, line);
      if (!Array.isArray(b)) throw new SdFault('E305', 'chỉ gán được vào phần tử mảng', line);
      if (typeof iv !== 'number') throw new SdFault('E305', 'chỉ số phải là số nguyên', line);
      if (iv < 0 || iv >= b.length) throw new SdFault('E404', `chỉ số ${iv} ngoài khoảng 0..${b.length - 1}`, line);
      b[iv] = val;
    }
    else if (k === 'fld') {
      const o = this.ev(lhs[1], env, line);
      if (!(o instanceof Struct) || !o.f.has(lhs[2])) throw new SdFault('E301', `không có trường '${lhs[2]}'`, line);
      o.f.set(lhs[2], val);
    }
    else if (k === 'deref') this.derefSet(this.ev(lhs[1], env, line), val, line);
    else if (k === 'gvar') { if (!this.globals.has(lhs[1])) throw new SdFault('E301', `biến toàn cục '${lhs[1]}' chưa khai báo`, line); this.globals.set(lhs[1], val); }
    else throw new SdFault('E303', 'vế trái không gán được', line);
  }
  run(stmts, env) { const e = env.concat([new Map()]); for (const st of stmts) this.exec(st, e); }
  setIpt(st, env, n, cur, line) {
    const raw = line.trim(); let v;
    if (typeof cur === 'number') { if (!/^[-+]?\d+$/.test(raw)) throw new SdFault('E403', `nhập sai kiểu int: '${raw}'`, n); v = parseInt(raw, 10); }
    else if (cur instanceof Fl) { const f = Number(raw); if (raw === '' || Number.isNaN(f)) throw new SdFault('E403', `nhập sai kiểu float: '${raw}'`, n); v = new Fl(f); }
    else v = raw;
    this.assign(st[2], v, env, n);
  }
  exec(st, env) {
    if (++this.steps > STEP_LIMIT) throw new SdFault('E501', 'vượt giới hạn số bước (có thể là vòng lặp vô hạn)', st[1]);
    const k = st[0], n = st[1];
    if (k === 'decl') {
      const [, , typ, nm, size, init] = st;
      const sc = env[env.length - 1];
      if (sc.has(nm) || (this.p.isPP && this.globals.has(nm))) throw new SdFault('E302', `trùng tên '${nm}'`, n);
      let v = this.def(typ, size);
      if (init !== null) v = this.copy(this.ev(init, env, n));
      sc.set(nm, v);
    }
    else if (k === 'assign') this.assign(st[2], this.copy(this.ev(st[3], env, n)), env, n);
    else if (k === 'pri') {
      const a = st[2]; let text;
      if (a.startsWith('"')) { const m = /^"(.*)"$/.exec(a); text = this.fmt(m ? m[1] : a.slice(1), env, n); }
      else text = fstr(this.ev(parseExpr(a, n), env, n));
      this.write(text + '\n', n);
    }
    else if (k === 'ipt') {
      const cur = this.ev(st[2], env, n);
      if (this.ip >= this.inp.length) {
        if (this.waitInput) throw new NeedInput();
        throw new SdFault('E403', 'hết dữ liệu nhập (thêm dòng vào tab Nhập liệu)', n);
      }
      this.setIpt(st, env, n, cur, this.inp[this.ip++]);
    }
    else if (k === 'nop') { /* init ... */ }
    else if (k === 'sbback') { if (!this.sbDepth) throw new SdFault('E409', "'$$' ngoài ids sb là dừng khẩn cấp (Hard Halt)", n); throw new SbBack(); }
    else if (k === 'sbexit') { if (!this.sbDepth) { if (st[2] === 'break') throw new Brk(); throw new SdFault('E202', "'transf' chỉ dùng trong ids sb", n); } throw new SbExit(); }
    else if (k === 'sb') this.sbRun(st, env, n);
    else if (k === 'expr') this.ev(st[2], env, n);
    else if (k === 'ret') throw new Ret(this.ev(st[2], env, n));
    else if (k === 'brk') throw new Brk();
    else if (k === 'nxt') throw new Nxt();
    else if (k === 'if') {
      for (const [cond, b] of st[2]) if (cond === null || truthy(this.ev(cond, env, n))) { this.run(b, env); break; }
    }
    else if (k === 'while') {
      while (truthy(this.ev(st[2], env, n))) {
        if (++this.steps > STEP_LIMIT) throw new SdFault('E501', 'vượt giới hạn số bước (có thể là vòng lặp vô hạn)', n);
        try { this.run(st[3], env); } catch (x) { if (x instanceof Brk) break; if (!(x instanceof Nxt)) throw x; }
      }
    }
    else if (k === 'for') {
      const env2 = env.concat([new Map()]);
      this.exec(st[2], env2);
      while (truthy(this.ev(st[3], env2, n))) {
        if (++this.steps > STEP_LIMIT) throw new SdFault('E501', 'vượt giới hạn số bước (có thể là vòng lặp vô hạn)', n);
        try { this.run(st[5], env2); } catch (x) { if (x instanceof Brk) break; if (!(x instanceof Nxt)) throw x; }
        this.exec(st[4], env2);
      }
    }
  }
}


function hasCall(e) {
  if (e._h !== undefined) return e._h;
  let h = e[0] === 'call';
  if (!h) for (const c of e.slice(1)) {
    if (!Array.isArray(c)) continue;
    if (typeof c[0] === 'string') { if (hasCall(c)) { h = true; break; } }
    else if (c.some((x) => Array.isArray(x) && hasCall(x))) { h = true; break; }
  }
  e._h = h; return h;
}
class DVM extends VM {
  constructor(prog, stdin, write) { super(prog, stdin, write); this.stack = []; this.fileStack = []; }
  curFile() { return this.fileStack.length ? this.fileStack[this.fileStack.length - 1] : null; }
  *evG(e, env, line) {
    if (!hasCall(e)) return this.ev(e, env, line);
    const k = e[0];
    if (k === 'call') { if (e[1] === 'sta.free') return this.ev(e, env, line); const a = []; for (const x of e[2]) a.push(yield* this.evG(x, env, line)); return yield* this.callG(e[1], a, line); }
    if (k === 'bin') {
      const a = yield* this.evG(e[2], env, line);
      if (e[1] === 'and') return truthy(a) ? yield* this.evG(e[3], env, line) : a;
      if (e[1] === 'or') return truthy(a) ? a : yield* this.evG(e[3], env, line);
      return this.arith(e[1], a, yield* this.evG(e[3], env, line), line);
    }
    if (k === 'neg' || k === 'not') return this.ev([k, ['val', yield* this.evG(e[1], env, line)]], env, line);
    if (k === 'idx') { const b = yield* this.evG(e[1], env, line); const i = yield* this.evG(e[2], env, line); return this.ev(['idx', ['val', b], ['val', i]], env, line); }
    if (k === 'fld') return this.ev(['fld', ['val', yield* this.evG(e[1], env, line)], e[2]], env, line);
    if (k === 'list') { const r = []; for (const x of e[1]) r.push(yield* this.evG(x, env, line)); return r; }
    return this.ev(e, env, line);
  }
  *callG(name, args, line) {
    const fn = this.p.fns.get(name);
    if (!fn) return this.call(name, args, line);
    if (fn.params.length !== args.length) throw new SdFault('E304', `${name}: cần ${fn.params.length} đối số, nhận ${args.length}`, line);
    if (++this.depth > DEPTH_LIMIT) throw new SdFault('E402', 'tràn ngăn xếp (đệ quy quá sâu)', line);
    const sc = new Map(); fn.params.forEach(([, pn], i) => sc.set(pn, this.copy(args[i])));
    this.stack.push(name + '(' + args.map(fstr).join(', ') + ')');
    this.fileStack.push(fn.file || null);
    try { yield* this.runG(fn.body, [sc]); }
    catch (r) { if (r instanceof Ret) return this.copy(r.v); if (r instanceof SdFault && !r.file && fn.file) r.file = fn.file; throw r; }
    finally { this.depth--; this.stack.pop(); this.fileStack.pop(); }
    return null;
  }
  *fmtG(s, env, line) {
    let res = '', i = 0;
    while (i < s.length) {
      if (s.startsWith('//', i)) { res += '/'; i += 2; continue; }
      const m = /^\/([sdfb])(\d?)\{/.exec(s.slice(i, i + 4));
      if (!m) { res += s[i]; i++; continue; }
      const j = i + m[0].length; let d = 1, k = j;
      while (d) {
        if (k >= s.length) throw new SdFault('E201', "thiếu '}' đóng chỗ giữ chỗ", line);
        if (s[k] === '{') d++; else if (s[k] === '}') d--; k++;
      }
      const v = yield* this.evG(parseExpr(s.slice(j, k - 1), line), env, line);
      const c = m[1];
      if (c === 's') res += fstr(v);
      else if (c === 'b') res += truthy(v) ? 'true' : 'false';
      else {
        if (!isNum(v)) throw new SdFault('E305', `/${c}{} cần số, nhận ${this.tn(v)}`, line);
        res += c === 'd' ? String(Math.trunc(nv(v))) : nv(v).toFixed(m[2] === '' ? 2 : parseInt(m[2], 10));
      }
      i = k;
    }
    return res;
  }
  *runG(stmts, env) { const e = env.concat([new Map()]); for (const st of stmts) yield* this.execG(st, e, false); }
  *execG(st, env, quiet) {
    const k = st[0], n = st[1];
    if (!quiet) yield { line: n, env, depth: this.stack.length, stack: this.stack.slice(), file: this.curFile() };
    if (++this.steps > STEP_LIMIT) throw new SdFault('E501', 'vượt giới hạn số bước (có thể là vòng lặp vô hạn)', n);
    if (k === 'decl') {
      const [, , typ, nm, size, init] = st; const sc = env[env.length - 1];
      if (sc.has(nm) || (this.p.isPP && this.globals.has(nm))) throw new SdFault('E302', `trùng tên '${nm}'`, n);
      let v = this.def(typ, size);
      if (init !== null) v = this.copy(yield* this.evG(init, env, n));
      sc.set(nm, v);
    }
    else if (k === 'assign') { const v = this.copy(yield* this.evG(st[3], env, n)); this.assign(st[2], v, env, n); }
    else if (k === 'ipt') {
      const cur = this.ev(st[2], env, n);
      if (this.ip >= this.inp.length) { const ln = yield { need: true, line: n, env, depth: this.stack.length, stack: this.stack.slice(), file: this.curFile() }; this.inp.push(String(ln)); }
      this.setIpt(st, env, n, cur, this.inp[this.ip++]);
    }
    else if (k === 'pri') {
      const a = st[2]; let text;
      if (a.startsWith('"')) { const m = /^"(.*)"$/.exec(a); text = yield* this.fmtG(m ? m[1] : a.slice(1), env, n); }
      else text = fstr(yield* this.evG(parseExpr(a, n), env, n));
      this.write(text + '\n', n);
    }
    else if (k === 'expr') yield* this.evG(st[2], env, n);
    else if (k === 'ret') throw new Ret(yield* this.evG(st[2], env, n));
    else if (k === 'if') {
      for (const [cond, b] of st[2]) if (cond === null || truthy(yield* this.evG(cond, env, n))) { yield* this.runG(b, env); break; }
    }
    else if (k === 'while') {
      while (truthy(yield* this.evG(st[2], env, n))) {
        if (++this.steps > STEP_LIMIT) throw new SdFault('E501', 'vượt giới hạn số bước (có thể là vòng lặp vô hạn)', n);
        try { yield* this.runG(st[3], env); } catch (x) { if (x instanceof Brk) break; if (!(x instanceof Nxt)) throw x; }
        yield { line: n, env, depth: this.stack.length, stack: this.stack.slice(), file: this.curFile() };
      }
    }
    else if (k === 'for') {
      const env2 = env.concat([new Map()]);
      yield* this.execG(st[2], env2, true);
      while (truthy(yield* this.evG(st[3], env2, n))) {
        if (++this.steps > STEP_LIMIT) throw new SdFault('E501', 'vượt giới hạn số bước (có thể là vòng lặp vô hạn)', n);
        try { yield* this.runG(st[5], env2); } catch (x) { if (x instanceof Brk) break; if (!(x instanceof Nxt)) throw x; }
        yield* this.execG(st[4], env2, true);
      }
    }
    else if (k === 'sb') yield* this.sbRunG(st, env, n);
    else this.exec(st, env);
  }
  *sbRunG(st, env, n) {
    this.sbDepth++; let backs = 0;
    try {
      for (;;) {
        let chosen = null;
        for (const [c, b] of st[3]) if (c !== null && truthy(yield* this.evG(c, env, n))) { chosen = b; break; }
        if (!chosen) { const r = st[3].find((x) => x[0] === null); if (!r) return; chosen = r[1]; }
        try { yield* this.runG(chosen, env); return; }
        catch (x) {
          if (x instanceof SbBack) {
            if (++backs > 65536) throw new SdFault('E402', 'Reback vượt 65536 lần (vòng lặp vô hạn?)', n);
            yield { line: n, env, depth: this.stack.length, stack: this.stack.slice(), file: this.curFile() }; continue;
          }
          if (x instanceof SbExit) return;
          throw x;
        }
      }
    } finally { this.sbDepth--; }
  }
  *main() {
    this.initGlobals();
    try { yield* this.runG(this.p.main, [new Map()]); return 0; }
    catch (r) { if (r instanceof Ret) return typeof r.v === 'number' || r.v instanceof Fl ? Math.trunc(nv(r.v)) : 0; throw r; }
  }
}

/* Phien chay co the dung / chay tung buoc / cho nhap. */
function createDebug(src, stdin, onOut, opts) {
  const d = { out: '', done: false, fault: null, rc: null, pos: null, waiting: false, vm: null, warnings: [] };
  const mk = () => ({ load: opts && opts.load, stack: opts && opts.entry ? [String(opts.entry).toLowerCase()] : [], done: new Set() });
  const pre = checkAll(src, opts).fault;
  if (pre) { d.done = true; d.fault = pre; d.rc = 255; return d; }
  const prog = buildProg(src, mk());
  const vm = new DVM(prog, stdin || '', (s, ln) => {
    if (d.out.length + s.length > OUT_LIMIT) throw new SdFault('E501', 'đầu ra quá dài', ln);
    d.out += s; if (onOut) onOut(s);
  });
  d.vm = vm; const gen = vm.main();
  const fail = (e) => {
    d.done = true; d.pos = null; d.waiting = false; d.rc = 255;
    d.fault = e instanceof SdFault ? e : e instanceof RangeError ? new SdFault('E402', 'tràn ngăn xếp (đệ quy quá sâu)', 0)
      : (e instanceof Brk || e instanceof Nxt) ? new SdFault('E202', "'brk' hoặc 'nxt' đặt ngoài vòng lặp", 0)
      : new SdFault('E500', 'lỗi nội bộ: ' + (e && e.message), 0);
  };
  /* tien toi diem dung ke tiep */
  d.next = (line) => {
    if (d.done) return;
    try {
      const r = d.waiting ? gen.next(line) : gen.next();
      d.waiting = false;
      if (r.done) { d.done = true; d.rc = r.value; d.pos = null; d.warnings = vm.leakWarnings(); }
      else { d.pos = r.value; d.waiting = !!r.value.need; }
    } catch (e) { fail(e); }
  };
  /* mode: 'in' | 'over' | 'out' | 'go'; bps: Set dong */
  d.go = (mode, bps) => {
    const depth0 = d.pos ? d.pos.depth : 0, line0 = d.pos ? d.pos.line : 0;
    let first = true;
    for (let i = 0; i < 3000000 && !d.done; i++) {
      d.next(d.waiting ? undefined : undefined);
      if (d.done || d.waiting) return;
      const p = d.pos;
      if (mode === 'in') return;
      if (mode === 'over' && p.depth <= depth0) return;
      if (mode === 'out' && p.depth < depth0) return;
      if (bps && bps.has((p.file || '') + ':' + p.line)) return;
      first = false;
    }
  };
  d.vars = () => {
    const seen = new Set(), rows = [];
    if (!d.pos) return rows;
    const env = d.pos.env;
    for (let i = env.length - 1; i >= 0; i--) for (const [k, v] of env[i]) if (!seen.has(k)) { seen.add(k); rows.push([k, fstr(v), v instanceof Fl ? 'float' : vm.tn(v)]); }
    return rows;
  };
  d.next();           /* dung o lenh dau tien cua main */
  return d;
}

/* Phan tich de bao loi + canh bao truc tiep. */
function checkAll(src, opts) {
  PARSE_WARN.length = 0;
  try {
    const p = buildProg(src, { load: opts && opts.load, stack: opts && opts.entry ? [String(opts.entry).toLowerCase()] : [], done: new Set() });
    const seen = new Set(), w = [];
    for (const x of (p.warnings || []).concat(PARSE_WARN)) { const key = x.code + x.line; if (!seen.has(key)) { seen.add(key); w.push(x); } }
    if (p.main === null) return { fault: new SdFault('E204', isPP(src) ? "thiếu khung chính trong define[...]{ main: {...} } €" : "thiếu khối 'sta(main){ ... }'", 1), warnings: w };
    return { fault: null, warnings: w };
  } catch (e) {
    let f = e instanceof SdFault ? e : new SdFault('E202', String(e.message || e), 1);
    if ((f.code === 'E202' || f.code === 'E201') && !isPP(src) && /\b(ids\.|iptedt\.|define\s*\[)/.test(src)) f = new SdFault(f.code, f.msg + " (có vẻ là mã Sd++: cần bọc trong 'ssta { ... }' và kết thúc bằng '##')", f.line);
    return { fault: f, warnings: [] };
  }
}
function checkSource(src, opts) { return checkAll(src, opts).fault; }

function runSource(src, stdin, opts) {
  let out = ''; let outLen = 0; const t0 = Date.now();
  const write = (s, line) => {
    outLen += s.length;
    if (outLen > OUT_LIMIT) throw new SdFault('E501', 'đầu ra quá dài (giới hạn 400000 ký tự)', line);
    out += s;
  };
  const fin = (rc, fault, warnings) => ({ rc, out, fault: fault || null, warnings: warnings || [], ms: Date.now() - t0 });
  const pre = checkSource(src, opts);
  if (pre) return fin(255, pre);
  try {
    const prog = buildProg(src, { load: opts && opts.load, stack: opts && opts.entry ? [String(opts.entry).toLowerCase()] : [], done: new Set() });
    const vm = new VM(prog, stdin || '', write); vm.waitInput = !!(opts && opts.interactive);
    try { vm.initGlobals(); vm.run(prog.main, [new Map()]); return fin(0, null, vm.leakWarnings()); }
    catch (r) {
      if (r instanceof Ret) return fin(typeof r.v === 'number' || r.v instanceof Fl ? Math.trunc(nv(r.v)) : 0, null, vm.leakWarnings());
      throw r;
    }
  } catch (e) {
    if (e instanceof NeedInput) { const r = fin(0); r.needInput = true; return r; }
    if (e instanceof SdFault) return fin(255, e);
    if (e instanceof RangeError) return fin(255, new SdFault('E402', 'tràn ngăn xếp (đệ quy quá sâu)', 0));
    if (e instanceof Brk || e instanceof Nxt) return fin(255, new SdFault('E202', "'brk' hoặc 'nxt' đặt ngoài vòng lặp", 0));
    return fin(255, new SdFault('E500', 'lỗi nội bộ: ' + (e && e.message), 0));
  }
}
if (typeof module !== 'undefined') module.exports = { runSource, checkSource, checkAll, createDebug, SdFault };
